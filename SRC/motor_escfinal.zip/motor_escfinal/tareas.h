#ifndef TAREAS_H
#define TAREAS_H

#include <Arduino.h>
#include "hardware.h"

// Periodos de ejecución de las tareas (ms)
constexpr uint16_t CONTROL_TASK_PERIOD_MS  = 20;
constexpr uint16_t MONITOR_TASK_PERIOD_MS  = 500;

// Parámetros de FreeRTOS
constexpr uint16_t CONTROL_TASK_STACK_SIZE = 4096;
constexpr uint16_t MONITOR_TASK_STACK_SIZE = 4096;

constexpr UBaseType_t CONTROL_TASK_PRIORITY = 2;
constexpr UBaseType_t MONITOR_TASK_PRIORITY = 1;

constexpr BaseType_t  TASK_CORE_ID          = 1;

// Handles de tareas
extern TaskHandle_t taskControlMotorHandle;
extern TaskHandle_t taskMonitorHandle;

// Crea las tareas FreeRTOS
void crearTareas();

#endif
