#include "tareas.h"

// Handles de las tareas
TaskHandle_t taskControlMotorHandle = nullptr;
TaskHandle_t taskMonitorHandle      = nullptr;

// ==== Tarea de control del motor (rápida) ====
// Lee potenciómetro y actualiza el ESC continuamente.
void taskControlMotorFunction(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    actualizarEscDesdePotenciometro();
    vTaskDelay(pdMS_TO_TICKS(CONTROL_TASK_PERIOD_MS));
  }
}

// ==== Tarea de monitoreo (más lenta) ====
// Calcula RPM, lee temperatura, actualiza Serial + LCD.
void taskMonitorFunction(void *pvParameters) {
  (void) pvParameters;

  for (;;) {
    short rpm               = calcularRpmDesdeEncoder();
    float temperatureCelsius = leerTemperaturaAmbienteC();

    // ---- Monitor Serial ----
    Serial.print("ADC=");
    Serial.print(potentiometerAdcValue);
    Serial.print("  PWM(us)=");
    Serial.print(escPulseWidthMicroseconds);
    Serial.print("  RPM=");
    Serial.print(rpm);

    if (bmeInitialized && !isnan(temperatureCelsius)) {
      Serial.print("  Temp=");
      Serial.print(temperatureCelsius);
      Serial.print(" C");
    } else {
      Serial.print("  Temp= --- (BME no inicializado)");
    }
    Serial.println();

    // ---- Pantalla LCD ----
    actualizarPantalla(rpm, temperatureCelsius);

    vTaskDelay(pdMS_TO_TICKS(MONITOR_TASK_PERIOD_MS));
  }
}

// ==== Creador de tareas ====
void crearTareas() {
  // Tarea de control del motor
  xTaskCreatePinnedToCore(
    taskControlMotorFunction,      // función
    "ControlMotor",                // nombre
    CONTROL_TASK_STACK_SIZE,       // stack
    nullptr,                       // parámetros
    CONTROL_TASK_PRIORITY,         // prioridad
    &taskControlMotorHandle,       // handle
    TASK_CORE_ID                   // core
  );

  // Tarea de monitoreo
  xTaskCreatePinnedToCore(
    taskMonitorFunction,
    "Monitor",
    MONITOR_TASK_STACK_SIZE,
    nullptr,
    MONITOR_TASK_PRIORITY,
    &taskMonitorHandle,
    TASK_CORE_ID
  );

  Serial.println("Tareas FreeRTOS creadas.\n");
}
