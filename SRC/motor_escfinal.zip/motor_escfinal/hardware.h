#ifndef HARDWARE_H
#define HARDWARE_H

#include <Arduino.h>
#include <ESP32Servo.h>
#include "my_i2c.h"

// ================== FreeRTOS ==================
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// ================== CONFIGURACIÓN GENERAL ==================
constexpr unsigned long SERIAL_BAUD_RATE            = 115200UL;
constexpr uint16_t      SERIAL_STARTUP_DELAY_MS     = 1000;

// ================== PINES MOTOR / ENCODER ==================
constexpr uint8_t PIN_ESC_PWM                       = 4;   // Pin PWM hacia el ESC
constexpr uint8_t PIN_POTENTIOMETER_ADC             = 34;  // Pin ADC del potenciómetro
constexpr uint8_t PIN_ENCODER_SIGNAL                = 27;  // Pin del encoder

// Encoder
constexpr uint8_t  ENCODER_PULSES_PER_REVOLUTION    = 40;  // Pulsos por vuelta

// ================== ADC ==================
constexpr uint8_t  ADC_RESOLUTION_BITS              = 12;  // 12 bits -> 0..4095
constexpr uint16_t ADC_MAX_VALUE                    = (1u << ADC_RESOLUTION_BITS) - 1u;

// ================== ESC (CONTROL DEL MOTOR) ==================
constexpr uint8_t  ESC_PWM_FREQUENCY_HZ             = 50;
constexpr uint16_t ESC_MIN_PULSE_WIDTH_US           = 1000;
constexpr uint16_t ESC_MAX_PULSE_WIDTH_US           = 2000;
constexpr uint16_t ESC_ARMING_TIME_MS               = 1500;

// ================== I2C COMPARTIDO (LCD + BME280) ==================
constexpr int      I2C_SDA_PIN                      = 21;
constexpr int      I2C_SCL_PIN                      = 22;

// ================== LCD ==================
constexpr uint8_t  LCD_I2C_ADDRESS                  = 0x27;
constexpr uint8_t  LCD_NUM_COLUMNS                  = 16;
constexpr uint8_t  LCD_NUM_ROWS                     = 2;
constexpr char     LCD_DEGREE_SYMBOL                = static_cast<char>(223);

// ================== RANGO DE RPM PARA MOSTRAR EN LCD ==================
constexpr short RPM_DISPLAY_MIN                     = 1;
constexpr short RPM_DISPLAY_MAX                     = 1000;

// ================== DRIVER SIMPLE LCD I2C ==================
// Asumimos backpack tipo PCF8574 compatible
class SimpleLCD_I2C {
public:
  SimpleLCD_I2C(uint8_t address, uint8_t columns, uint8_t rows);

  void init();
  void clear();
  void setCursor(uint8_t column, uint8_t row);

  void print(const char *text);
  void print(int value);
  void print(float value, uint8_t decimals = 1);
  void print(char c);

private:
  uint8_t _deviceAddress;
  uint8_t _numColumns;
  uint8_t _numRows;
  uint8_t _backlightMask;

  // Constantes del controlador HD44780 / backpack
  static constexpr uint8_t LCD_BACKLIGHT_MASK_DEFAULT              = 0x08;
  static constexpr uint8_t LCD_ENABLE_BIT                          = 0x04;
  static constexpr uint8_t LCD_INIT_FUNCTION_8BIT_MODE             = 0x30;
  static constexpr uint8_t LCD_INIT_FUNCTION_4BIT_MODE             = 0x20;
  static constexpr uint8_t LCD_COMMAND_FUNCTION_SET_4BIT_2LINE_5x8 = 0x28;
  static constexpr uint8_t LCD_COMMAND_DISPLAY_OFF                 = 0x08;
  static constexpr uint8_t LCD_COMMAND_CLEAR_DISPLAY               = 0x01;
  static constexpr uint8_t LCD_COMMAND_ENTRY_MODE_SET              = 0x06;
  static constexpr uint8_t LCD_COMMAND_DISPLAY_ON_CURSOR_OFF       = 0x0C;
  static constexpr uint8_t LCD_COMMAND_SET_DDRAM_ADDRESS           = 0x80;

  void send(uint8_t value, bool isData);
  void write4bits(uint8_t data);
  void pulseEnable(uint8_t data);
  void expanderWrite(uint8_t data);
};

// ================== DRIVER SIMPLE BME280 (sólo temperatura) ==================
class SimpleBME280 {
public:
  SimpleBME280();

  bool  begin(uint8_t address);     // Inicializa el sensor
  float readTemperatureCelsius();   // Devuelve temperatura en °C
  bool  isOK() const { return _isInitialized; }

private:
  uint8_t _deviceAddress;
  bool    _isInitialized;

  // Coeficientes de calibración de temperatura
  uint16_t calibrationT1;
  int16_t  calibrationT2;
  int16_t  calibrationT3;
  float    fineTemperature;

  // Registros / constantes (datasheet)
  static constexpr uint8_t BME280_CHIP_ID_VALUE          = 0x60;
  static constexpr uint8_t BME280_REGISTER_ID            = 0xD0;
  static constexpr uint8_t BME280_REGISTER_CALIB_T1      = 0x88;
  static constexpr uint8_t BME280_REGISTER_CALIB_T2      = 0x8A;
  static constexpr uint8_t BME280_REGISTER_CALIB_T3      = 0x8C;
  static constexpr uint8_t BME280_REGISTER_CTRL_MEAS     = 0xF4;
  static constexpr uint8_t BME280_REGISTER_TEMP_MSB      = 0xFA;
  static constexpr uint8_t BME280_TEMPERATURE_SETTINGS   = 0x23; // osrs_t x1, normal mode

  uint8_t  read8(uint8_t registerAddress);
  uint16_t read16LittleEndian(uint8_t registerAddress);
  void     write8(uint8_t registerAddress, uint8_t value);
};

// ================== OBJETOS GLOBALES ==================
extern Servo         motorEsc;
extern SimpleBME280  environmentalSensor;
extern SimpleLCD_I2C displayLcd;
extern bool          bmeInitialized;

// ================== ENCODER / RPM ==================
extern volatile unsigned long encoderPulseCount;
extern unsigned long           encoderLastSampleMillis;
extern short                   currentRpm;

// ================== ESTADO COMPARTIDO (CONTROL DEL MOTOR) ==================
extern int potentiometerAdcValue;          // último valor leído del potenciómetro
extern int escPulseWidthMicroseconds;      // último PWM enviado al ESC (µs)

// ================== PROTOTIPOS ==================
void IRAM_ATTR onEncoderPulse();          // ISR del encoder

short calcularRpmDesdeEncoder();          // Calcula RPM a partir del contador
float leerTemperaturaAmbienteC();         // Lee temperatura del BME (o NAN)
void actualizarEscDesdePotenciometro();   // Lee pote y actualiza ESC
void actualizarPantalla(short rpm, float temperatureC);  // Muestra datos en LCD

void inicializarHardware();               // Configura TODO el hardware

#endif
