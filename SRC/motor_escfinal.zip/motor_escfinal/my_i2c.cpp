#include "my_i2c.h"

namespace MyI2C {

void begin(int sdaPin, int sclPin, uint32_t frequencyHz) {
  Wire.begin(sdaPin, sclPin, frequencyHz);
}

bool writeByte(uint8_t deviceAddress, uint8_t registerAddress, uint8_t data) {
  Wire.beginTransmission(deviceAddress);
  Wire.write(registerAddress);
  Wire.write(data);
  return (Wire.endTransmission() == 0);
}

bool writeBytes(uint8_t deviceAddress, const uint8_t* data, size_t length) {
  Wire.beginTransmission(deviceAddress);
  Wire.write(data, length);
  return (Wire.endTransmission() == 0);
}

bool readBytes(uint8_t deviceAddress, uint8_t registerAddress, uint8_t* buffer, size_t length) {
  Wire.beginTransmission(deviceAddress);
  Wire.write(registerAddress);

  // repeated start
  if (Wire.endTransmission(false) != 0) {
    return false;
  }

  size_t bytesRead = Wire.requestFrom(static_cast<int>(deviceAddress),
                                      static_cast<int>(length));

  if (bytesRead != length) {
    return false;
  }

  for (size_t i = 0; i < length; ++i) {
    if (Wire.available()) {
      buffer[i] = Wire.read();
    } else {
      return false;
    }
  }
  return true;
}

} // namespace MyI2C
