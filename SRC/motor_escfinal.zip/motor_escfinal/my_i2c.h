#ifndef MY_I2C_H
#define MY_I2C_H

#include <Arduino.h>
#include <Wire.h>

namespace MyI2C {

  // Frecuencia por defecto del bus I2C (400 kHz)
  constexpr uint32_t I2C_DEFAULT_FREQUENCY_HZ = 400000;

  // Inicializa el bus I2C
  void begin(int sdaPin, int sclPin, uint32_t frequencyHz = I2C_DEFAULT_FREQUENCY_HZ);

  // Escribe 1 byte en un registro (addr + reg + data)
  bool writeByte(uint8_t deviceAddress, uint8_t registerAddress, uint8_t data);

  // Escribe un buffer de bytes sin registro (solo addr + data[])
  bool writeBytes(uint8_t deviceAddress, const uint8_t* data, size_t length);

  // Lee 'length' bytes desde un registro
  bool readBytes(uint8_t deviceAddress, uint8_t registerAddress, uint8_t* buffer, size_t length);

} // namespace MyI2C

#endif
