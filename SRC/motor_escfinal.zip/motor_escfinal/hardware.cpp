#include "hardware.h"

// ================== OBJETOS ==================
Servo         motorEsc;
SimpleBME280  environmentalSensor;
SimpleLCD_I2C displayLcd(LCD_I2C_ADDRESS, LCD_NUM_COLUMNS, LCD_NUM_ROWS);

bool bmeInitialized = false;

// ================== ENCODER / RPM ==================
volatile unsigned long encoderPulseCount        = 0;
unsigned long           encoderLastSampleMillis = 0;
short                   currentRpm              = 0;

// ================== ESTADO COMPARTIDO ==================
int potentiometerAdcValue        = 0;
int escPulseWidthMicroseconds    = ESC_MIN_PULSE_WIDTH_US;

// ------------------------------------------------------
// IMPLEMENTACIÓN SimpleLCD_I2C
// ------------------------------------------------------
SimpleLCD_I2C::SimpleLCD_I2C(uint8_t address, uint8_t columns, uint8_t rows)
: _deviceAddress(address),
  _numColumns(columns),
  _numRows(rows),
  _backlightMask(LCD_BACKLIGHT_MASK_DEFAULT)
{}

// Envía un byte al expander I2C usando MyI2C
void SimpleLCD_I2C::expanderWrite(uint8_t data) {
  uint8_t dataWithBacklight = static_cast<uint8_t>(data | _backlightMask);
  MyI2C::writeBytes(_deviceAddress, &dataWithBacklight, 1);
}

// Pulso en la señal EN del LCD
void SimpleLCD_I2C::pulseEnable(uint8_t data) {
  expanderWrite(static_cast<uint8_t>(data | LCD_ENABLE_BIT));   // EN = 1
  delayMicroseconds(1);
  expanderWrite(static_cast<uint8_t>(data & ~LCD_ENABLE_BIT));  // EN = 0
  delayMicroseconds(50);
}

// Escribir 4 bits (nibble alto) al LCD
void SimpleLCD_I2C::write4bits(uint8_t data) {
  expanderWrite(data);
  pulseEnable(data);
}

// Enviar comando/dato (8 bits) desdoblado en 2 nibbles
void SimpleLCD_I2C::send(uint8_t value, bool isData) {
  uint8_t rsMask = isData ? 0x01 : 0x00;   // RS en bit 0
  uint8_t high   = static_cast<uint8_t>((value & 0xF0) | rsMask);
  uint8_t low    = static_cast<uint8_t>(((value << 4) & 0xF0) | rsMask);

  write4bits(high);
  write4bits(low);
}

// Inicialización típica de un HD44780 en modo 4 bits
void SimpleLCD_I2C::init() {
  delay(50);

  // Secuencia de inicio en modo 8 bits para luego pasar a 4 bits
  write4bits(LCD_INIT_FUNCTION_8BIT_MODE);
  delayMicroseconds(4500);
  write4bits(LCD_INIT_FUNCTION_8BIT_MODE);
  delayMicroseconds(4500);
  write4bits(LCD_INIT_FUNCTION_8BIT_MODE);
  delayMicroseconds(150);
  write4bits(LCD_INIT_FUNCTION_4BIT_MODE);

  // Function set: 4 bits, 2 líneas, font 5x8
  send(LCD_COMMAND_FUNCTION_SET_4BIT_2LINE_5x8, false);
  // Display off
  send(LCD_COMMAND_DISPLAY_OFF, false);
  // Clear display
  send(LCD_COMMAND_CLEAR_DISPLAY, false);
  delay(2);
  // Entry mode set
  send(LCD_COMMAND_ENTRY_MODE_SET, false);
  // Display on, cursor off
  send(LCD_COMMAND_DISPLAY_ON_CURSOR_OFF, false);
}

void SimpleLCD_I2C::clear() {
  send(LCD_COMMAND_CLEAR_DISPLAY, false);
  delay(2);
}

void SimpleLCD_I2C::setCursor(uint8_t column, uint8_t row) {
  static const uint8_t rowOffsets[] = {0x00, 0x40, 0x14, 0x54};
  if (row >= _numRows) {
    row = static_cast<uint8_t>(_numRows - 1);
  }
  uint8_t address = static_cast<uint8_t>(
    LCD_COMMAND_SET_DDRAM_ADDRESS + rowOffsets[row] + column
  );
  send(address, false);
}

void SimpleLCD_I2C::print(const char *text) {
  while (*text != '\0') {
    send(static_cast<uint8_t>(*text), true);
    ++text;
  }
}

void SimpleLCD_I2C::print(int value) {
  String stringValue(value);
  print(stringValue.c_str());
}

void SimpleLCD_I2C::print(float value, uint8_t decimals) {
  // ✅ Evita ambigüedad del constructor String(float, uint8_t)
  String stringValue(value, static_cast<unsigned int>(decimals));
  print(stringValue.c_str());
}

void SimpleLCD_I2C::print(char c) {
  send(static_cast<uint8_t>(c), true);
}

// ------------------------------------------------------
// IMPLEMENTACIÓN SimpleBME280 (sólo temperatura) con MyI2C
// ------------------------------------------------------
SimpleBME280::SimpleBME280()
: _deviceAddress(0),
  _isInitialized(false),
  calibrationT1(0),
  calibrationT2(0),
  calibrationT3(0),
  fineTemperature(0.0f)
{}

uint8_t SimpleBME280::read8(uint8_t registerAddress) {
  uint8_t value = 0;
  if (!MyI2C::readBytes(_deviceAddress, registerAddress, &value, 1)) {
    return 0;
  }
  return value;
}

uint16_t SimpleBME280::read16LittleEndian(uint8_t registerAddress) {
  uint8_t buffer[2] = {0, 0};
  if (!MyI2C::readBytes(_deviceAddress, registerAddress, buffer, 2)) {
    return 0;
  }
  // Little-endian: LSB primero
  uint16_t value = static_cast<uint16_t>(buffer[1] << 8 | buffer[0]);
  return value;
}

void SimpleBME280::write8(uint8_t registerAddress, uint8_t value) {
  MyI2C::writeByte(_deviceAddress, registerAddress, value);
}

bool SimpleBME280::begin(uint8_t address) {
  _deviceAddress  = address;
  _isInitialized  = false;

  // Leer ID del chip
  uint8_t chipId = read8(BME280_REGISTER_ID);
  if (chipId != BME280_CHIP_ID_VALUE) {
    return false;
  }

  // Leer coeficientes de calibración de temperatura
  calibrationT1 = read16LittleEndian(BME280_REGISTER_CALIB_T1);
  calibrationT2 = static_cast<int16_t>(read16LittleEndian(BME280_REGISTER_CALIB_T2));
  calibrationT3 = static_cast<int16_t>(read16LittleEndian(BME280_REGISTER_CALIB_T3));

  // Configurar oversampling mínimo sólo para temperatura, modo normal
  write8(BME280_REGISTER_CTRL_MEAS, BME280_TEMPERATURE_SETTINGS);

  _isInitialized = true;
  return true;
}

float SimpleBME280::readTemperatureCelsius() {
  if (!_isInitialized) {
    return NAN;
  }

  // Datos crudos de temperatura (20 bits)
  uint8_t rawTemperature[3] = {0, 0, 0};
  if (!MyI2C::readBytes(_deviceAddress,
                        BME280_REGISTER_TEMP_MSB,
                        rawTemperature,
                        3)) {
    return NAN;
  }

  int32_t adc_T = (static_cast<int32_t>(rawTemperature[0]) << 12) |
                  (static_cast<int32_t>(rawTemperature[1]) << 4)  |
                  (static_cast<int32_t>(rawTemperature[2]) >> 4);

  // Fórmulas de compensación de temperatura (datasheet BME280)
  const float scaleVar1Denominator = 16384.0f;
  const float scaleVar2Denominator = 131072.0f;
  const float t1Scale1             = 1024.0f;
  const float t1Scale2             = 8192.0f;
  const float tFineScale           = 5120.0f;

  float var1 = (((static_cast<float>(adc_T) / scaleVar1Denominator) -
                 (static_cast<float>(calibrationT1) / t1Scale1)) *
                static_cast<float>(calibrationT2));

  float tempIntermediate = (static_cast<float>(adc_T) / scaleVar2Denominator) -
                           (static_cast<float>(calibrationT1) / t1Scale2);

  float var2 = (tempIntermediate * tempIntermediate) *
               static_cast<float>(calibrationT3);

  fineTemperature = var1 + var2;
  float temperatureC = fineTemperature / tFineScale;

  return temperatureC;
}

// ------------------------------------------------------
// ENCODER / RPM
// ------------------------------------------------------
void IRAM_ATTR onEncoderPulse() {
  ++encoderPulseCount;
}

short calcularRpmDesdeEncoder() {
  // Tomamos snapshot del contador de pulsos de forma atómica
  noInterrupts();
  unsigned long pulseCountSnapshot = encoderPulseCount;
  encoderPulseCount = 0;
  interrupts();

  unsigned long currentMillis = millis();
  unsigned long elapsedTimeMs = currentMillis - encoderLastSampleMillis;
  encoderLastSampleMillis     = currentMillis;

  if (elapsedTimeMs == 0 || pulseCountSnapshot == 0) {
    currentRpm = 0;
    return currentRpm;
  }

  // 60000 ms = 1 minuto
  float pulsesPerMinute = (static_cast<float>(pulseCountSnapshot) * 60000.0f) /
                          static_cast<float>(elapsedTimeMs);

  float rpmFloat = pulsesPerMinute /
                   static_cast<float>(ENCODER_PULSES_PER_REVOLUTION);

  if (rpmFloat < 0.0f) {
    rpmFloat = 0.0f;
  }

  currentRpm = static_cast<short>(rpmFloat);
  return currentRpm;
}

// ------------------------------------------------------
// FUNCIONES DE ALTO NIVEL: TEMP, ESC, LCD
// ------------------------------------------------------
float leerTemperaturaAmbienteC() {
  if (!bmeInitialized) {
    return NAN;
  }
  return environmentalSensor.readTemperatureCelsius();
}

void actualizarEscDesdePotenciometro() {
  potentiometerAdcValue     = analogRead(PIN_POTENTIOMETER_ADC);
  escPulseWidthMicroseconds = map(potentiometerAdcValue,
                                  0,
                                  ADC_MAX_VALUE,
                                  ESC_MIN_PULSE_WIDTH_US,
                                  ESC_MAX_PULSE_WIDTH_US);
  motorEsc.writeMicroseconds(escPulseWidthMicroseconds);
}

// Pantalla muestra REV (1–1000 RPM) y temperatura
void actualizarPantalla(short rpm, float temperatureC) {
  displayLcd.clear();

  // Línea 0: Revoluciones
  displayLcd.setCursor(0, 0);
  displayLcd.print("REV:");

  if (rpm >= RPM_DISPLAY_MIN && rpm <= RPM_DISPLAY_MAX) {
    displayLcd.print(rpm);
  } else if (rpm > RPM_DISPLAY_MAX) {
    displayLcd.print(">1000");
  } else {
    // rpm == 0 o negativa => sin giro
    displayLcd.print(0);
  }

  // Línea 1: Temperatura ambiente
  displayLcd.setCursor(0, 1);
  displayLcd.print("T:");

  if (bmeInitialized && !isnan(temperatureC)) {
    displayLcd.print(temperatureC, 1);       // 1 decimal
    displayLcd.print(LCD_DEGREE_SYMBOL);     // símbolo de grado
    displayLcd.print("C");
  } else {
    displayLcd.print("---");
  }
}

// ------------------------------------------------------
// INICIALIZACIÓN COMPLETA DEL HARDWARE
// ------------------------------------------------------
void inicializarHardware() {
  Serial.begin(SERIAL_BAUD_RATE);
  delay(SERIAL_STARTUP_DELAY_MS);

  Serial.println("=== Motor + Encoder + BME280 + LCD I2C (MyI2C + FreeRTOS) ===");

  // ---- ADC ----
  analogReadResolution(ADC_RESOLUTION_BITS);

  // ---- ESC ----
  motorEsc.setPeriodHertz(ESC_PWM_FREQUENCY_HZ);
  motorEsc.attach(PIN_ESC_PWM, ESC_MIN_PULSE_WIDTH_US, ESC_MAX_PULSE_WIDTH_US);
  motorEsc.writeMicroseconds(ESC_MIN_PULSE_WIDTH_US);   // mínimo
  delay(ESC_ARMING_TIME_MS);                            // tiempo de armado del ESC

  // ---- Encoder ----
  // Muchos módulos HC-020K / similar necesitan pull-up
  pinMode(PIN_ENCODER_SIGNAL, INPUT_PULLUP);
  encoderLastSampleMillis = millis();
  attachInterrupt(
    digitalPinToInterrupt(PIN_ENCODER_SIGNAL),
    onEncoderPulse,
    RISING
  );

  // ---- Bus I2C compartido (LCD + BME280) ----
  MyI2C::begin(I2C_SDA_PIN, I2C_SCL_PIN);
  Serial.println("Bus I2C iniciado en SDA=21, SCL=22 via MyI2C");

  // ---- LCD I2C (driver propio) ----
  displayLcd.init();
  displayLcd.clear();
  displayLcd.setCursor(0, 0);
  displayLcd.print("Motor ESC + REV");
  displayLcd.setCursor(0, 1);
  displayLcd.print("Iniciando...");

  // ---- BME280 con driver propio ----
  Serial.println("Intentando iniciar BME280 en 0x76...");
  if (environmentalSensor.begin(0x76)) {
    Serial.println("BME280 encontrado en 0x76");
    bmeInitialized = true;
  } else {
    Serial.println("No responde en 0x76, probando 0x77...");
    if (environmentalSensor.begin(0x77)) {
      Serial.println("BME280 encontrado en 0x77");
      bmeInitialized = true;
    } else {
      Serial.println("ERROR: BME280 no se pudo iniciar en 0x76 ni 0x77");
      Serial.println("Revise direccion I2C, conexionado o si el modulo no es BME280.");
      bmeInitialized = false;
    }
  }

  Serial.println("Configuración de hardware completada.\n");
}
