#include "freertos_config.h"
#include "imu_mpu6050.h"
#include "bme280_sensor.h"
#include "encoder.h"
#include "motor.h"
#include "display_i2c.h"

// Queues compartidas
QueueHandle_t q_rpm;        // float RPM
QueueHandle_t q_imu;        // imu_t
QueueHandle_t q_env;        // env_t

static const char *TAG = "main";

void app_main(void)
{
    ESP_LOGI(TAG, "Iniciando sistema macro-micro centrífuga");

    // Crear colas
    q_rpm = xQueueCreate(5, sizeof(float));
    q_imu = xQueueCreate(3, sizeof(imu_t));
    q_env = xQueueCreate(3, sizeof(env_t));

    // Inicializar hardware (I2C, PWM, GPIO...)
    display_i2c_init();       // I2C init inside
    imu_mpu6050_init();
    bme280_init();
    encoder_init();
    motor_init();

    // Crear tareas
    xTaskCreate(encoder_task,     "EncoderTask",    TASK_STACK_SMALL, (void*)q_rpm, PRIORITY_RPM_READ, NULL);
    xTaskCreate(motor_task,       "MotorTask",      TASK_STACK_SMALL, (void*)q_rpm, PRIORITY_MOTOR_CTRL, NULL);
    xTaskCreate(imu_task,         "IMUTask",        TASK_STACK_SMALL, (void*)q_imu, PRIORITY_SENSOR_IMU, NULL);
    xTaskCreate(env_task,         "EnvTask",        TASK_STACK_SMALL, (void*)q_env, PRIORITY_SENSOR_ENV, NULL);
    xTaskCreate(display_task,     "DisplayTask",    TASK_STACK_SMALL, (void*)NULL, PRIORITY_DISPLAY, NULL);

    ESP_LOGI(TAG, "Tareas creadas");
}
