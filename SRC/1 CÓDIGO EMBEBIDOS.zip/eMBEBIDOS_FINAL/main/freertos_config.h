#include "freertos_config.h"

#define TASK_STACK_SMALL  4096
#define TASK_STACK_MEDIUM 8192
#define TASK_STACK_LARGE  12288

// Prioridades (mayor número = mayor prioridad)
#define PRIORITY_RPM_READ    6
#define PRIORITY_MOTOR_CTRL  6
#define PRIORITY_SAFETY      6
#define PRIORITY_SENSOR_IMU  5
#define PRIORITY_SENSOR_ENV  4
#define PRIORITY_DISPLAY     3
#define PRIORITY_LOGGER      2
