#include "imu_mpu6050.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include "freertos_config.h"
#include "main/freertos_config.h"
#include "sdkconfig.h"
#include "math.h"
#include "esp_system.h"
#include "main.h" // para q_imu si necesario (o pasar cola como arg)

static const char *TAG = "MPU6050";
#define MPU6050_ADDR 0x68

// Pines I2C básicos (ajusta)
#define I2C_PORT_NUM I2C_NUM_0
#define I2C_SDA_PIN 21
#define I2C_SCL_PIN 22

void imu_mpu6050_init(void)
{
    // Inicializar I2C (si no se inicializó)
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_SDA_PIN,
        .scl_io_num = I2C_SCL_PIN,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = 100000
    };
    i2c_param_config(I2C_PORT_NUM, &conf);
    i2c_driver_install(I2C_PORT_NUM, conf.mode, 0, 0, 0);

    // Wake-up MPU6050
    uint8_t wake_cmd[2] = {0x6B, 0x00};
    i2c_master_write_to_device(I2C_PORT_NUM, MPU6050_ADDR, wake_cmd, 2, 1000 / portTICK_PERIOD_MS);
    ESP_LOGI(TAG, "MPU6050 inicializado");
}

void imu_task(void *arg)
{
    QueueHandle_t q_imu = (QueueHandle_t) arg;
    imu_t imu;
    TickType_t last_wake = xTaskGetTickCount();
    while (1) {
        // Lectura simplificada: deberías implementar lectura de registros y conversión
        // Aquí ponemos ejemplo de valores ficticios para que la estructura compile
        imu.ax = 0.0f;
        imu.ay = 0.0f;
        imu.az = 9.8f;
        imu.gx = 0.0f;
        imu.gy = 0.0f;
        imu.gz = 0.0f;
        imu.temp = 25.0f;

        if (q_imu) xQueueOverwrite(q_imu, &imu);
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(50)); // 20 Hz
    }
}
