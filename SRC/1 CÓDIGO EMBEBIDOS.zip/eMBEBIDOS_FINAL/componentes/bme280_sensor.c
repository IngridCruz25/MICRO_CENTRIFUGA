#include "bme280_sensor.h"
#include "driver/i2c.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "BME280";
#define BME280_ADDR 0x76
#define I2C_PORT_NUM I2C_NUM_0

void bme280_init(void)
{
    // Asume I2C ya inicializado por MPU init, pero puedes inicializar aquí si quieres.
    ESP_LOGI(TAG, "BME280 init (direccion 0x%02x)", BME280_ADDR);
    // Aquí puedes colocar la inicialización específica o usar librería bme280.
}

void env_task(void *arg)
{
    QueueHandle_t q_env = (QueueHandle_t) arg;
    env_t env;
    TickType_t last_wake = xTaskGetTickCount();
    while (1) {
        // Lectura ficticia: reemplazar con lectura real BME280
        env.temp = 24.0f;
        env.hum = 45.0f;
        env.pres = 1013.25f;

        if (q_env) xQueueOverwrite(q_env, &env);
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(1000)); // 1 Hz
    }
}
