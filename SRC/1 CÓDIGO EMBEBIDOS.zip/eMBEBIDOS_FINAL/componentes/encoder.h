#pragma once
#include <stdint.h>

void encoder_init(void);
void encoder_task(void *arg); // envía float RPM por la cola recibida
