#include "display_i2c.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include <stdio.h>

static const char *TAG = "Display";

void display_i2c_init(void)
{
    // Asume I2C ya configurado. Si usas un adaptador I2C-LCD,
    // aquí inicializa la librería de LCD. Ejemplo: inicializar HD44780 por I2C.
    ESP_LOGI(TAG, "Display I2C init");
}

void display_task(void *arg)
{
    extern QueueHandle_t q_rpm;
    extern QueueHandle_t q_imu;
    extern QueueHandle_t q_env;

    float rpm = 0.0f;
    imu_t imu;
    env_t env;

    TickType_t last_wake = xTaskGetTickCount();
    while (1) {
        // Leer (no bloquear) las colas
        if (q_rpm) xQueuePeek(q_rpm, &rpm, 0);
        if (q_imu) xQueuePeek(q_imu, &imu, 0);
        if (q_env) xQueuePeek(q_env, &env, 0);

        // Mostrar en pantalla (ejemplo texto)
        // Aquí deberías llamar funciones específicas de la librería LCD:
        // lcd_clear();
        // lcd_printf("RPM: %.0f\nT:%.1fC P:%.0fhPa", rpm, env.temp, env.pres);

        ESP_LOGI(TAG, "Display -> RPM: %.1f  T: %.1fC  H: %.1f%%", rpm, env.temp, env.hum);

        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(500)); // actualizar 2 Hz
    }
}
