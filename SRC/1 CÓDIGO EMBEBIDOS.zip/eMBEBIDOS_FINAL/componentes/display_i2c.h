#pragma once
#include "bme280_sensor.h"
#include "imu_mpu6050.h"

void display_i2c_init(void);
void display_task(void *arg); // lee colas y actualiza el display
