#pragma once
void motor_init(void);
void motor_set_duty(float duty_percent); // 0-100
void motor_task(void *arg); // lee RPM desde cola y regula PWM (control PI simple)
