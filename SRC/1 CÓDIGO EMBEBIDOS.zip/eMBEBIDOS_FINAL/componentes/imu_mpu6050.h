#pragma once
#include <stdint.h>

typedef struct {
    float ax, ay, az;
    float gx, gy, gz;
    float temp;
} imu_t;

void imu_mpu6050_init(void);
void imu_task(void *arg); // tarea FreeRTOS que publica en cola (push imu_t)
