#include "encoder.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

static const char *TAG = "Encoder";
#define ENCODER_PIN GPIO_NUM_4  // ajustar
static volatile uint32_t pulse_count = 0;
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;

static void IRAM_ATTR encoder_isr_handler(void* arg) {
    portENTER_CRITICAL_ISR(&mux);
    pulse_count++;
    portEXIT_CRITICAL_ISR(&mux);
}

void encoder_init(void)
{
    gpio_config_t io_conf = {
        .intr_type = GPIO_INTR_POSEDGE,
        .mode = GPIO_MODE_INPUT,
        .pin_bit_mask = (1ULL << ENCODER_PIN),
        .pull_down_en = 0,
        .pull_up_en = 1
    };
    gpio_config(&io_conf);
    gpio_install_isr_service(0);
    gpio_isr_handler_add(ENCODER_PIN, encoder_isr_handler, NULL);
    ESP_LOGI(TAG, "Encoder inicializado en pin %d", ENCODER_PIN);
}

void encoder_task(void *arg)
{
    QueueHandle_t q_rpm = (QueueHandle_t) arg;
    const TickType_t period = pdMS_TO_TICKS(200); // calcular RPM cada 200ms
    uint32_t last_count = 0;
    while (1) {
        vTaskDelay(period);
        portENTER_CRITICAL(&mux);
        uint32_t count = pulse_count;
        pulse_count = 0;
        portEXIT_CRITICAL(&mux);

        // Ejemplo: si el encoder da N pulsos por vuelta (adjust PPR)
        const float PULSES_PER_REV = 20.0f; // ajustar segun encoder
        float revs = ((float)count) / PULSES_PER_REV;
        float rpm = (revs) * (60.0f / (0.2f)); // periodo 0.2s => factor 60/0.2 = 300
        if (q_rpm) xQueueOverwrite(q_rpm, &rpm);
    }
}
