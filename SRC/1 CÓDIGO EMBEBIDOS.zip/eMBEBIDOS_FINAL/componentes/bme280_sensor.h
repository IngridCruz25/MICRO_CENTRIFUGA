#pragma once
typedef struct {
    float temp;
    float hum;
    float pres;
} env_t;

void bme280_init(void);
void env_task(void *arg); // publica env_t en cola
